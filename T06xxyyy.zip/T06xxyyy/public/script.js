const users = ['Me', 'Friend A', 'Friend B'];
const posts = [];

export { users, posts }