import express from "express";
import { users, posts } from "./public/script.js";
import path from "path";

const port = 3000;

const app = express();

app.use(express.static("public"));

app.use(express.urlencoded({ extended: false }));

app.set("view engine", "ejs");

app.use(express.json());

app.use((req, res, next) => {
  res.locals.users = users;
  next();
});

app.get("/", (req, res) => {
  res.render("index", { posts });
});

app.get("/add", (req, res) => {
  //   res.render("add", { users, warning: false });
  res.render("add", { warning: false });
});

app.post("/add", validate, (req, res) => {
  res.redirect("/");
});

app.listen(port, () => {
  console.log(`port ${port}`);
});

function validate(req, res, next) {
  let tagStr = req.body.tags;
  req.arrTag = tagStr.split(",");
  let boolean = true;

  if (req.arrTag.includes(req.body.author)) {
    boolean = false;
  } else {
    for (let i = 0; i < req.arrTag.length; i++) {
      if (!users.includes(req.arrTag[i])) {
        boolean = false;
      }
    }
  }

  if (boolean == false) {
    res.render("add", { warning: true });
  } else {
    const post = {
      author: req.body.author,
      konten: req.body.konten,
      tags: req.arrTag,
    };
    posts.push(post);
    next();
  }
}
